import threading
import time
import json

class Inventory:
    def __init__(self):
        self.items = {}

    def add_item(self, item_name, quantity):
        if item_name in self.items:
            self.items[item_name] += quantity
        else:
            self.items[item_name] = quantity

    def remove_item(self, item_name, quantity):
        if item_name in self.items:
            if self.items[item_name] >= quantity:
                self.items[item_name] -= quantity
                if self.items[item_name] == 0:
                    del self.items[item_name]
            else:
                print(f"Not enough stock to remove {quantity} of {item_name}.")
        else:
            print(f"Item {item_name} not found in inventory.")

    def check_stock(self, item_name):
        return self.items.get(item_name, 0)

    def save_to_file(self, filename):
        try:
            with open(filename, 'w') as file:
                json.dump(self.items, file)
        except IOError as e:
            print(f"Error saving inventory to file: {e}")

    def load_from_file(self, filename):
        try:
            with open(filename, 'r') as file:
                self.items = json.load(file)
        except IOError as e:
            print(f"Error loading inventory from file: {e}")

    def check_stock_levels(self):
        while True:
            for item_name, quantity in self.items.items():
                if quantity < 10:
                    print(f"Alert: Low stock for {item_name}. Current stock: {quantity}")
            time.sleep(10)

def main():
    inventory = Inventory()
    inventory.add_item('Widget', 25)
    inventory.add_item('Gadget', 5)
    inventory.remove_item('Gadget', 1)
    inventory.save_to_file('inventory.json')

    stock_checker_thread = threading.Thread(target=inventory.check_stock_levels, daemon=True)
    stock_checker_thread.start()

    inventory.load_from_file('inventory.json')
    print(f"Current inventory: {inventory.items}")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Program interrupted.")

if __name__ == "__main__":
    main()
