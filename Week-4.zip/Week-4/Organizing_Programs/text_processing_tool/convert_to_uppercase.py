def convert_to_uppercase(text):
    return text.upper()
