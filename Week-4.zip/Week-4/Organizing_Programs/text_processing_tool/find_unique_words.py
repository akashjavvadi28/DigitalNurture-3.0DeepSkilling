def find_unique_words(text):
    words = text.split()
    return set(words)
