from abc import ABC, abstractmethod

class DiscountStrategy(ABC):
    @abstractmethod
    def apply_discount(self, order_amount):
        pass

class RegularDiscount(DiscountStrategy):
    def apply_discount(self, order_amount):
        return order_amount

class PremiumDiscount(DiscountStrategy):
    def apply_discount(self, order_amount):
        return order_amount * 0.90

class VIPDiscount(DiscountStrategy):
    def apply_discount(self, order_amount):
        return order_amount * 0.80

class Order:
    def __init__(self, customer_type, order_amount):
        self.customer_type = customer_type
        self.order_amount = order_amount
        self.discount_strategy = self._set_discount_strategy()

    def _set_discount_strategy(self):
        if self.customer_type == "regular":
            return RegularDiscount()
        elif self.customer_type == "premium":
            return PremiumDiscount()
        elif self.customer_type == "vip":
            return VIPDiscount()
        else:
            raise ValueError("Unknown customer type")

    def final_price(self):
        discounted_amount = self.discount_strategy.apply_discount(self.order_amount)
        return discounted_amount

orders = [
    Order(customer_type="regular", order_amount=100),
    Order(customer_type="premium", order_amount=100),
    Order(customer_type="vip", order_amount=100)
]

for order in orders:
    print(f"Customer Type: {order.customer_type.capitalize()}, Final Price: ${order.final_price():.2f}")
