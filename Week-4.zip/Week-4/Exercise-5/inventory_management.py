# Lists: Product Names
product_names = []

def add_product_name(name):
    if name not in product_names:
        product_names.append(name)
    else:
        print(f"Product {name} already exists.")

def remove_product_name(name):
    if name in product_names:
        product_names.remove(name)
    else:
        print(f"Product {name} not found.")

def update_product_name(old_name, new_name):
    if old_name in product_names:
        index = product_names.index(old_name)
        product_names[index] = new_name
    else:
        print(f"Product {old_name} not found.")

# Dictionaries: Product Details
product_details = {}

def add_product_details(name, quantity, price):
    product_details[name] = {'quantity': quantity, 'price': price}

def update_product_details(name, quantity=None, price=None):
    if name in product_details:
        if quantity is not None:
            product_details[name]['quantity'] = quantity
        if price is not None:
            product_details[name]['price'] = price
    else:
        print(f"Product {name} not found.")

def delete_product_details(name):
    if name in product_details:
        del product_details[name]
    else:
        print(f"Product {name} not found.")

# Tuples: Product Catalog
def create_product_catalog():
    return (
        ("Widget", 10, 20.00),
        ("Gadget", 5, 15.00),
        ("Doodad", 20, 25.00)
    )

def display_product_catalog(catalog):
    for product in catalog:
        name, quantity, price = product
        print(f"Product: {name}, Quantity: {quantity}, Price: ${price:.2f}")

# Sets: Product Categories
categories = set()

def add_category(category):
    categories.add(category)

def remove_category(category):
    if category in categories:
        categories.remove(category)
    else:
        print(f"Category {category} not found.")

# Combining Collections
def report_products_sorted_by_price():
    sorted_products = sorted(product_details.items(), key=lambda x: x[1]['price'])
    for name, details in sorted_products:
        print(f"Product: {name}, Quantity: {details['quantity']}, Price: ${details['price']:.2f}")

def find_products_in_price_range(min_price, max_price):
    in_range = {name for name, details in product_details.items() if min_price <= details['price'] <= max_price}
    print(f"Products in price range ${min_price:.2f} to ${max_price:.2f}: {in_range}")

# Example usage
def main():
    # Working with product names
    add_product_name("Widget")
    add_product_name("Gadget")
    remove_product_name("Doodad")
    update_product_name("Gadget", "Gizmo")

    # Working with product details
    add_product_details("Widget", 10, 20.00)
    add_product_details("Gizmo", 5, 15.00)
    update_product_details("Gizmo", price=18.00)
    delete_product_details("Widget")

    # Working with tuples
    catalog = create_product_catalog()
    display_product_catalog(catalog)

    # Working with sets
    add_category("Electronics")
    add_category("Toys")
    remove_category("Clothing")

    # Combining collections
    report_products_sorted_by_price()
    find_products_in_price_range(10, 20)

if __name__ == "__main__":
    main()
