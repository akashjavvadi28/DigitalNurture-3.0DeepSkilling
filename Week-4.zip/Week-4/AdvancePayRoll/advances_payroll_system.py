
class Employee:
    def __init__(self, name, hours_worked, hourly_rate):
        self.name = name
        self.hours_worked = hours_worked
        self.hourly_rate = hourly_rate

    def calculate_pay(self):
        
        regular_hours = min(self.hours_worked, 40)
        overtime_hours = max(self.hours_worked - 40, 0)
        
       
        regular_pay = regular_hours * self.hourly_rate
        overtime_pay = overtime_hours * self.hourly_rate * 1.5
        
        total_pay = regular_pay + overtime_pay
        return total_pay


class Manager(Employee):
    def __init__(self, name, hours_worked, hourly_rate, bonus):
        super().__init__(name, hours_worked, hourly_rate)
        self.bonus = bonus

    def calculate_pay(self):
     
        base_pay = super().calculate_pay()
        

        total_pay = base_pay + self.bonus
        return total_pay


employee = Employee(name="Roy", hours_worked=45, hourly_rate=20)
print(f"Employee Pay: ${employee.calculate_pay():.2f}")


manager = Manager(name="Akash", hours_worked=50, hourly_rate=30, bonus=500)
print(f"Manager Pay: ${manager.calculate_pay():.2f}")
