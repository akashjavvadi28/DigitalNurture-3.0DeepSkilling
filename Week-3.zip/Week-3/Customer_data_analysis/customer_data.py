customer_data={'Alice': 120, 'Bob': 75, 'Charlie': 90}
def update_purchase(customer_data,name,amount):
    if name in customer_data:
        customer_data[name]=amount
    else:
        print(f"{name} not found in customer data")
update_purchase(customer_data,'Bob',100)
print("Updated Customer Data:")
for name,amount in customer_data.items():
    print(f"{name}: ${amount}")