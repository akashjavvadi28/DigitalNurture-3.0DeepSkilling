worked_hours=int(input("NO.OF HOURS WORKED:"))
hourly_rate=int(input("RATE PER HOUR:"))
def calculate_pay(hours,rate):
    total_pay= hours*rate
    return total_pay
pay=calculate_pay(worked_hours,hourly_rate)
print(f"The total pay for the employee is: ${pay}")