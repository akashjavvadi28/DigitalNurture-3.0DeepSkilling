order_amount=int(input())
def apply_discount(order_amount):
    if order_amount > 100:
        order_amount *= 0.9  
    return order_amount
final_price = apply_discount(order_amount)
print(f"The final price after applying the discount is: ${final_price:.2f}")

    