# contact_management.py

# Function to add a contact to the text file
def add_contact(name, phone):
    with open("D:\Cognizant\Week-5\Exercise-1\contacts.txt", "a") as file:
        file.write(f"{name},{phone}\n")
    print(f"Contact {name} added.")

# Function to display all contacts from the text file
def display_contacts():
    try:
        with open("D:\Cognizant\Week-5\Exercise-1\contacts.txt", "r") as file:
            contacts = file.readlines()
            if contacts:
                print("Contacts:")
                for contact in contacts:
                    name, phone = contact.strip().split(",")
                    print(f"Name: {name}, Phone: {phone}")
            else:
                print("No contacts found.")
    except FileNotFoundError:
        print("Contacts file not found.")

# Function to remove a contact from the text file
def remove_contact(name):
    try:
        with open("D:\Cognizant\Week-5\Exercise-1\contacts.txt", "r") as file:
            contacts = file.readlines()

        with open("D:\Cognizant\Week-5\Exercise-1\contacts.txt", "w") as file:
            found = False
            for contact in contacts:
                contact_name, _ = contact.strip().split(",")
                if contact_name != name:
                    file.write(contact)
                else:
                    found = True

            if found:
                print(f"Contact {name} removed.")
            else:
                print(f"Contact {name} not found.")
    except FileNotFoundError:
        print("Contacts file not found.")
        
import pickle
binary_file_path = "D:\\Cognizant\\Week-5\\Exercise-1\\contacts.dat"

# Function to add a contact to the binary file
def add_contact_binary(name, phone):
    contacts = load_contacts_binary()
    contacts.append({"name": name, "phone": phone})
    save_contacts_binary(contacts)
    print("Contacts saved in binary format.")

# Function to load contacts from the binary file
def load_contacts_binary():
    try:
        with open(binary_file_path, "rb") as file:
            contacts = pickle.load(file)
    except (EOFError, FileNotFoundError):
        contacts = []
    return contacts

# Function to save contacts to the binary file
def save_contacts_binary(contacts):
    with open(binary_file_path, "wb") as file:
        pickle.dump(contacts, file)

# Function to display contacts from the binary file
def display_contacts_binary():
    contacts = load_contacts_binary()
    if contacts:
        for contact in contacts:
            print(f"Name: {contact['name']}, Phone: {contact['phone']}")
    else:
        print("No contacts found in binary file.")

# Function to remove a contact from the binary file
def remove_contact_binary(name):
    contacts = load_contacts_binary()
    contacts = [contact for contact in contacts if contact["name"] != name]
    save_contacts_binary(contacts)
    print(f"Contact {name} removed from binary file.")
def main():
    while True:
        print("\nContact Management System")
        print("1. Add Contact (Text)")
        print("2. Display Contacts (Text)")
        print("3. Remove Contact (Text)")
        print("4. Add Contact (Binary)")
        print("5. Display Contacts (Binary)")
        print("6. Remove Contact (Binary)")
        print("7. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            name = input("Enter name: ")
            phone = input("Enter phone: ")
            add_contact(name, phone)
        elif choice == "2":
            display_contacts()
        elif choice == "3":
            name = input("Enter name to remove: ")
            remove_contact(name)
        elif choice == "4":
            name = input("Enter name: ")
            phone = input("Enter phone: ")
            add_contact_binary(name, phone)
        elif choice == "5":
            display_contacts_binary()
        elif choice == "6":
            name = input("Enter name to remove: ")
            remove_contact_binary(name)
        elif choice == "7":
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
