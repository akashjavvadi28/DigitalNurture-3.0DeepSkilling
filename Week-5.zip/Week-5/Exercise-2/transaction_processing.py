import datetime
import os

# Function to log errors with a timestamp
def log_error(error):
    with open("error_log.txt", "a") as file:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        file.write(f"[{timestamp}] {str(error)}\n")

# Function to validate transaction data
def validate_transaction(amount):
    try:
        amount = float(amount)
        if amount <= 0:
            raise ValueError("Transaction amount must be greater than zero.")
        return amount
    except ValueError as ve:
        log_error(ve)
        raise

# Function to process a transaction
def process_transaction(amount):
    try:
        # Validate the transaction amount
        amount = validate_transaction(amount)
        
        # Simulate transaction processing
        print(f"Transaction processed: ${amount}")
        
        # Log the successful transaction
        log_transaction(amount)

    except ValueError as ve:
        print(f"Error: {ve}")
    except Exception as e:
        print("An unexpected error occurred.")
        log_error(e)

# Function to log successful transactions
def log_transaction(amount):
    with open("transaction_log.txt", "a") as file:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        file.write(f"[{timestamp}] Transaction of ${amount} processed successfully.\n")

# Function to display transaction history
def display_transaction_history():
    if not os.path.exists("transaction_log.txt"):
        print("No transaction history found.")
        return
    
    with open("transaction_log.txt", "r") as file:
        print("\nTransaction History:")
        print(file.read())

# Function to display error history
def display_error_history():
    if not os.path.exists("error_log.txt"):
        print("No error history found.")
        return
    
    with open("error_log.txt", "r") as file:
        print("\nError History:")
        print(file.read())

# Main loop for user interaction
def main():
    while True:
        print("\nTransaction Processing System")
        print("1. Process a transaction")
        print("2. View transaction history")
        print("3. View error history")
        print("4. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            transaction_amount = input("Enter the transaction amount: ")
            try:
                process_transaction(transaction_amount)
            except Exception as e:
                print(f"Transaction failed: {e}")
                log_error(e)
        elif choice == "2":
            display_transaction_history()
        elif choice == "3":
            display_error_history()
        elif choice == "4":
            print("Exiting the application.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
